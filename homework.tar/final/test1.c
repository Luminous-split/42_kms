#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>

#include "libft.h"

// lets learn pipe and fork and also execve 
/*
int	args(char *cmd)
{
	char **final_array;
	int count;
	int	i;

	count = 0;
	final_array = ft_split(cmd, ' ');
	while (*final_array != NULL)
	{
		printf("%s\n", *final_array);
		count++;
		final_array += 1;
	}
	i = -1;
	while(++i < count)
		free(final_array[i]);
	free(final_array);
	return (count);
}
*/

char	*prefix(char *cmd)
{
	const char *pref = "/bin/";
	char	*out;
	size_t	pref_len;
	size_t	cmd_len;

	pref_len = ft_strlen(pref);
	cmd_len = ft_strlen(cmd);
	out = malloc(sizeof(char) * (pref_len + cmd_len + 1));
	if (!out)
	{
		perror("malloc failed");
		return (NULL);
	}
	out[pref_len + cmd_len] = '\0';
	ft_memcpy(out, pref, pref_len);
	ft_memcpy(out + pref_len, cmd, cmd_len);
	return (out);
}

void cmdexe(char *cmd) {
	printf("\nInside cmdexe func\n");
	pid_t p1; // pid for forked processes
	pid_t p2;
	int	fd[2]; //int array for pipe


	if (pipe(fd) < 0)
	{
		perror("pipe failed");
		exit(1);
	}

	p1 = fork(); //gonna write  in child1
	if (p1 < 0)
	{
		perror("fork1 failed");
	}
	else if (p1 == 0) // check >> in child process or not
	{
		close(fd[0]); //close read end
		dup2(fd[1], STDOUT_FILENO);
		close(fd[1]);
//		ft_strlcat(path, cmd, sizeof(path));
//		execve(cmd, (char *[]){"cat", "-e", "a.out", NULL}, NULL);
		char **array = ft_split(cmd, ' ');
		execve(prefix(array[0]), array, NULL);
		perror("Exec failed");
		int i = -1;
		while(array[++i] != NULL)
			free(array[i]);
		free(array);
		_exit(0);
	}

	p2 = fork();
	if (p2 < 0)
	{
		perror("fork2 failed");
	}
	else if (p2 == 0) // write in child 2
	{
		close(fd[1]); //close the write end cuz not gna write in child2
		char buffer[1024];
		int	count;
		while ((count = read(fd[0], buffer, sizeof(buffer) - 1)) > 0)
		{
			buffer[count] = '\0';
			printf("%s", buffer);
		}
		close(fd[0]);
		_exit(0);
	}

	close(fd[0]);
	close(fd[1]);
}

int	main(int argc, char **argv)
{
	if (argc >= 2)
	{
		cmdexe(argv[1]);
//		char *out = prefix(argv[1]);
//		printf("%s", out);
//		free(out);
	}
}
