#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>
#include <fcntl.h>

#include "libft.h"
#include "pipex.h"
#include "get_next_line.h"

void*	ft_realloc(void* ptr,size_t old_size, size_t new_size)
{
    size_t copysize;

    if (new_size == 0) {
        free(ptr);
        return NULL;
    }
    if (ptr == NULL) {
        return malloc(new_size);
    }
    void* new_ptr = malloc(new_size);
    if (new_ptr == NULL) {
        return NULL;
    }
    copysize = new_size;
    if (old_size < new_size)
    	copysize = old_size;
    ft_memcpy(new_ptr, ptr, copysize);
    free(ptr);
    return new_ptr;
}

char	*prefix(char *cmd)
{
	const char *prefix = "/bin/";
	char	*out;
	size_t	prefix_len;
	size_t	cmd_len;

	prefix_len = ft_strlen(prefix);
	cmd_len = ft_strlen(cmd);
	out = malloc(sizeof(char) * (prefix_len + cmd_len + 1));
	if (!out)
	{
		perror("malloc failed");
		return (NULL);
	}
	out[prefix_len + cmd_len] = '\0';
	ft_memcpy(out, prefix, prefix_len);
	ft_memcpy(out + prefix_len, cmd, cmd_len);
	return (out);
}
///////////////////////////////////////////////////////////////////////
void	printarray(char **array)                                    ///
{							  	    ///
	int i = 0;						    ///
	while (array[i])
	{
		printf("|i = %d, %s|",i, array[i]);
		i++;
	}
}
///////////////////////////////////////////////////////////////////////

t_list_args *cmd_parse(int argc, char *argv[], int cmd_start, int *num_cmds)
    {
    t_list_args *cmds = NULL;
    int	count = 0;

    while (cmd_start < argc - 1)
    {
        t_list_args cmd;
	cmd.args = ft_split(argv[cmd_start], ' ');
        cmds = ft_realloc(cmds, count * sizeof(t_list_args), (count + 1) * sizeof(t_list_args));
        cmds[count++] = cmd;

        cmd_start++;
    }
    *num_cmds = count;
    return cmds;
}

void fork_pipe_execve(int infile_fd, int outfile_fd, t_list_args *cmds, int count) {
    int i = -1;
    int	in_fd = infile_fd;
    int	pipefd[2];

    while (++i < count)
    {
        if (i < count - 1 && pipe(pipefd) < 0)
        {
        	perror("pipe");
        	exit(1);
        }
////
        if (fork() == 0) {
            if (in_fd)
            {
             	dup2(in_fd, 0); //take from in_fd stdin 0
             	close(in_fd);
             }

            if (i < count - 1)
            {
            	close(pipefd[0]);
            	dup2(pipefd[1], 1); //send to 1 stdout 1
            	close(pipefd[1]);
            }
            else if (outfile_fd)
            {
            	dup2(outfile_fd, 1);
            	close(outfile_fd);
	    }
	    //else
	    //	close(pipefd[1]);

            execve(prefix(cmds[i].args[0]), cmds[i].args, NULL);
            perror("execve");
            exit(1);
        }
////
        if (in_fd)
        	close(in_fd);
        if (i < count - 1)
        {
        	close(pipefd[1]);
        	in_fd = pipefd[0];
        }
    }
    while (wait(NULL) > 0);
}

void free_all(t_list_args *cmds, int count)
{
	int i;
	i = -1;
	int j;

	while (++i < count)
	{
		j = 0;
		while (cmds[i].args[j])
		{
			free(cmds[i].args[j]);
			j++;
		}
		free(cmds[i].args);
	}
	free(cmds);
}

int	check(char *arg, char *limiter)
{
	char	*temp;

	temp = limiter;
	if (ft_strncmp(arg, "here_doc", ft_strlen("here_doc")) == 0 &&
	ft_strlen(arg) == ft_strlen("here_doc"))
		return (1);
	else if (ft_strncmp(arg, temp, ft_strlen(temp)) == 0 &&
	ft_strlen(arg) == ft_strlen(temp))
		return (2);
	return (0);
}

int	prepare_heredoc(char *limiter)
{
	int	pipefd[2];
	char	*str;
	int	last;

	last = 0;
	if (pipe(pipefd) < 0)
	{
		perror("pipe failed");
		exit(1);
	}
	if (fork() == 0)
	{
		close(pipefd[0]);
		while (1)
		{
			str = get_next_line(0, limiter);
			if (check(str, limiter) == 2 || str == NULL)
			{
				free(str);
				break ;
			}
//			printf("\nThe read str: %s\n", str); 
			ft_putendl_fd(str, pipefd[1]);
			free(str);
		}
		close(pipefd[1]);
		exit(0);
	}
	close(pipefd[1]);

	return (pipefd[0]);
}

int main(int argc, char *argv[]) {
	if (argc < 2) {
		printf("Usage: %s cmd1 [args] | cmd2 [args] | ...\n", argv[0]);
		return 1;
	}
	int num_cmds = 0;
	int	infile_fd;
	int	cmd_start;

	if (check(argv[1], argv[2]) == 1) //heredoc
{
		cmd_start = 3;
		infile_fd = prepare_heredoc(argv[2]);
//		printf("\nheredoc found\n"); 
}
	else
{
		infile_fd = open(argv[1], O_RDONLY);
		cmd_start = 2;
}
	int outfile_fd = open(argv[argc - 1], O_WRONLY);

	t_list_args *cmds = cmd_parse(argc, argv, cmd_start, &num_cmds);
	printf("\nCMD count: %d\n", num_cmds);
	printarray(cmds->args);
	fork_pipe_execve(infile_fd, outfile_fd, cmds, num_cmds);
	free_all(cmds, num_cmds);

	close(outfile_fd);
	return 0;
}

