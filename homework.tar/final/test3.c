#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>
#include <fcntl.h>

#include "libft.h"
#include "pipex.h"

void*	ft_realloc(void* ptr,size_t old_size, size_t new_size)
{
    size_t copysize;

    if (new_size == 0) {
        free(ptr);
        return NULL;
    }
    if (ptr == NULL) {
        return malloc(new_size);
    }
    void* new_ptr = malloc(new_size);
    if (new_ptr == NULL) {
        return NULL;
    }
    copysize = new_size;
    if (old_size < new_size)
    	copysize = old_size;
    ft_memcpy(new_ptr, ptr, copysize);
    free(ptr);
    return new_ptr;
}

char	*prefix(char *cmd)
{
	const char *prefix = "/bin/";
	char	*out;
	size_t	prefix_len;
	size_t	cmd_len;

	prefix_len = ft_strlen(prefix);
	cmd_len = ft_strlen(cmd);
	out = malloc(sizeof(char) * (prefix_len + cmd_len + 1));
	if (!out)
	{
		perror("malloc failed");
		return (NULL);
	}
	out[prefix_len + cmd_len] = '\0';
	ft_memcpy(out, prefix, prefix_len);
	ft_memcpy(out + prefix_len, cmd, cmd_len);
	return (out);
}
///////////////////////////////////////////////////////////////////////
void	printarray(char **array)                                    ///
{							  	    ///
	int i = 0;						    ///
	while (array[i])
	{
		printf("-%s-", array[i]);
		i++;
	}
}
///////////////////////////////////////////////////////////////////////

t_list_args *parse_commands(int argc, char *argv[], int *num_cmds)
    {
    t_list_args *cmds = NULL;
    int i = 2;
    int	count = 0;

    while (i < argc - 1)
    {
        t_list_args cmd;
	cmd.args = ft_split(argv[i], ' ');
	printarray(cmd.args);
        cmds = ft_realloc(cmds, count * sizeof(t_list_args), (count + 1) * sizeof(t_list_args));
        cmds[count++] = cmd;

        i++;
    }
    *num_cmds = count;
    return cmds;
}

void execute_pipeline(int infile_fd, int outfile_fd, t_list_args *cmds, int count) {
    int i = -1;
    int	in_fd = infile_fd;
    int	pipefd[2];

    while (++i < count)
    {
        if (i < count - 1 && pipe(pipefd) < 0)
        {
        	perror("pipe");
        	exit(1);
        }
////
        if (fork() == 0) {
            if (in_fd)
            {
             	dup2(in_fd, 0); //take from in_fd stdin 0
             	close(in_fd);
             }
            if (i < count - 1)
            {
            	close(pipefd[0]);
            	dup2(pipefd[1], 1); //send to 1 stdout 1
            	close(pipefd[1]);
            }
            else
            {
            	dup2(outfile_fd, 1);
            	close(pipefd[1]);
	    }
            execve(prefix(cmds[i].args[0]), cmds[i].args, NULL);
            perror("execve");
            exit(1);
        }
////
        if (in_fd)
        	close(in_fd);
        if (i < count - 1)
        {
        	close(pipefd[1]);
        	in_fd = pipefd[0];
        }
    }
    while (wait(NULL) > 0);
}

void free_all(t_list_args *cmds, int count)
{
    int i;
    i = -1;
    int j;

    while (++i < count)
        {
        	j = 0;
		while (cmds[i].args[j])
		{
			free(cmds[i].args[j]);
			j++;
		}
		free(cmds[i].args);
        }
    free(cmds);
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        fprintf(stderr, "Usage: %s cmd1 [args] | cmd2 [args] | ...\n", argv[0]);
        return 1;
    }
    int num_cmds = 0;
    int	infile_fd;
    if (ft_strncmp(argv[1], "here_doc", ft_strlen("here_doc")) == 0 &&
    strlen(argv[1]) == ft_strlen("here_doc"))
	infile_fd = 0;
    else
    	infile_fd = open(argv[1], O_RDONLY);
    printf("\nThe infile fd: %d\n", infile_fd); 
    int outfile_fd = open(argv[argc - 1], O_WRONLY | O_TRUNC);

    t_list_args *cmds = parse_commands(argc, argv, &num_cmds);
    execute_pipeline(infile_fd, outfile_fd, cmds, num_cmds);
    free_all(cmds, num_cmds);
    return 0;
}

