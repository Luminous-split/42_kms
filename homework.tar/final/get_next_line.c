/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ksan <ksan@student.42.sg>                  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/05/29 10:39:08 by ksan              #+#    #+#             */
/*   Updated: 2025/06/02 17:26:52 by ksan             ###   ########.sg       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include "get_next_line.h"

char	*ft_readline(char *read_line, int fd);

char	*ft_getline(char *line);

char	*get_next_line(int fd, char *limiter);

static int	check(char *str, char *limiter);

static int	ft_strncmp(const char *s1, const char *s2, size_t n);

static int	ft_strncmp(const char *s1, const char *s2, size_t n)
{
	unsigned char	s1i;
	unsigned char	s2i;
	size_t			i;

	i = 0;
	while (i < n)
	{
		s1i = (unsigned char)s1[i];
		s2i = (unsigned char)s2[i];
		if (s1i != s2i)
			return (s1i - s2i);
		if (s1i == '\0')
			return (0);
		i++;
	}
	return (0);
}

char	*ft_readline(char *line, int fd)
{
	char	*chunk_read;
	int		bytes_read;

	chunk_read = (char *)malloc((BUFFER_SIZE + 1) * sizeof(char));
	if (!chunk_read)
		return (NULL);
	bytes_read = 1;
	while (!ft_gnl_strchr(line, '\n') && bytes_read != 0)
	{
		bytes_read = read(fd, chunk_read, BUFFER_SIZE);
		if (bytes_read == -1)
		{
			free(chunk_read);
			return (NULL);
		}
		chunk_read[bytes_read] = '\0';
		line = ft_gnl_strjoin(line, chunk_read);
	}
	free(chunk_read);
	return (line);
}

char	*ft_getline(char *line)
{
	char	*result_line;
	int		i;

	i = 0;
	if (!line[i])
		return (NULL);
	while (line[i] && line[i] != '\n')
		i++;
	result_line = (char *)malloc(sizeof(char) * (i + 1));
	if (!result_line)
		return (NULL);
	i = 0;
	while (line[i] && line[i] != '\n')
	{
		result_line[i] = line[i];
		i++;
	}
	result_line[i] = '\0';
	return (result_line);
}

static int	check(char *str, char *limiter)
{
	if (ft_strncmp(str, limiter, ft_gnl_strlen(limiter)) == 0 &&
	ft_gnl_strlen(str) == ft_gnl_strlen(limiter))
		return (1);
	return (0);
}

char	*get_next_line(int fd, char *limiter)
{
	static char	*line;
	char		*output_line;

	if (BUFFER_SIZE <= 0 || fd < 0)
		return (NULL);
	line = ft_readline(line, fd);
	if (!line)
		return (NULL);
	output_line = ft_getline(line);
	if (check(output_line, limiter) == 1)
		free(line);
	else
		line = ft_prep_nex_line(line);
	return (output_line);
}

/*
#include <fcntl.h>
#include <stdio.h>
//test
int	main(int argc, char **argv)
{
	if (argc >= 2)
		printf("Good More than 2 [argcs]\n");

	int	fd = open(argv[1], O_RDONLY);
	if (fd < 0)
		printf("fd less than 0");
	char *str;
	while ((str = get_next_line(fd)) != NULL)
	{
		printf("%s", str);
		free(str);
	}
	close(fd);
	return (0);
}

*/
