
typedef struct {
    char **args;
} t_list_args;

