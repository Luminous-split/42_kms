#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>

#include "libft.h"

typedef struct {
    char **args;
} Command;

char	*prefix(char *cmd)
{
	const char *pref = "/bin/";
	char	*out;
	size_t	pref_len;
	size_t	cmd_len;

	pref_len = ft_strlen(pref);
	cmd_len = ft_strlen(cmd);
	out = malloc(sizeof(char) * (pref_len + cmd_len + 1));
	if (!out)
	{
		perror("malloc failed");
		return (NULL);
	}
	out[pref_len + cmd_len] = '\0';
	ft_memcpy(out, pref, pref_len);
	ft_memcpy(out + pref_len, cmd, cmd_len);
	return (out);
}

Command *parse_commands(int argc, char *argv[], int *num_cmds) {
    Command *cmds = NULL;
    int i = 1;
    int start = 1;
    int	count = 0;
    int j = -1;

    while (i <= argc) {
        if (i == argc || strcmp(argv[i], "|") == 0)
        {
            int len = i - start;
            if (len > 0) {
                Command cmd;
                cmd.args = malloc((len + 1) * sizeof(char *));
                while( ++j < len)
                    cmd.args[j] = argv[start + j];
                cmd.args[len] = NULL;
                cmds = realloc(cmds, (count + 1) * sizeof(Command));
                cmds[count++] = cmd;
            }
            start = i + 1;
        }
        i++;
    }
    *num_cmds = count;
    return cmds;
}

void execute_pipeline(Command *cmds, int count) {
    int i = -1, in_fd = 0, pipefd[2];
    while (++i < count)
    {
        if (i < count - 1 && pipe(pipefd) < 0)
        {
        	perror("pipe");
        	exit(1);
        }
////
        if (fork() == 0) {
            if (in_fd)
            {
             	dup2(in_fd, 0); //take from in_fd stdin 0
             	close(in_fd);
             }
            if (i < count - 1)
            {
            	close(pipefd[0]);
            	dup2(pipefd[1], 1); //send to 1 stdout 1
            	close(pipefd[1]);
            }

            execve(prefix(cmds[i].args[0]), cmds[i].args, NULL);
            perror("execve");
            exit(1);
        }
////
        if (in_fd)
        	close(in_fd);
        if (i < count - 1)
        {
        	close(pipefd[1]);
        	in_fd = pipefd[0];
        }
    }
    while (wait(NULL) > 0);
}

void free_commands(Command *cmds, int count)
{
    int i;
    i = -1;

    while (++i < count)
        free(cmds[i].args);
    free(cmds);
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        fprintf(stderr, "Usage: %s cmd1 [args] | cmd2 [args] | ...\n", argv[0]);
        return 1;
    }
    int num_cmds = 0;
    Command *cmds = parse_commands(argc, argv, &num_cmds);
    execute_pipeline(cmds, num_cmds);
    free_commands(cmds, num_cmds);
    return 0;
}

